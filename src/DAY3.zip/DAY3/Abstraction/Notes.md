# Abstraction in JAVA

Can be achieved using
- Abstract classes
- Abs Methods
- Abs Instance,variable.
- using interface