# Inheritance
One class aquires properties from another class.
**Types Using Classes**
1. Single level
2. Multilevel
3. Hierarchical Inheritance



**Interfaces in Java**
- "Interface" keyword is used
- Abstract methods and Constants are defined

Q.Why Interface is used ?


# Home work
- for each
- keywords
- Diamond Ambiguity Problem for Multiple inheritance
- Transient, permits, sealed, non-sealed
- Inheritance without extends keyword
- 1.Association
- 2.Composition

# Interface
- No instance Variable
- No Constructors
- Only final ,default, static ,abstract methods are allowed.
- Interface is a contract for class
