# Polymorphism in java

- One Interface, Many Implementaions
- Same Method name , Different Behavior
  
# Compile Time Polymorphism
- Method Overloading is the fun with same name but diff in Number of Paramer,Type of Parameter, Order of Parameter,Type of return value

# Types of Keyword in Java
1.this 
- Resolves Ambiguity and points to the current class object.
2.static
- Make it belongs to class.
3.final
- Prevent Extention
- Create Constants
4.abstract
- Hides implementation only shows the structure
- Runtime
5.extends
- create inheritance
6.interface
- Create interface
5.implements
- implements an interface
6.super
- Access data of parent class
- or refer to the parent object
7.instanceof
- Checks the object at runtime
8.enum
- Declare constant objects

Home Works
- sealed ,non-sealed,transiet,permits